import React from 'react'

export default function Userdetails() {
	const count=4;
  return (
	<div>
		<h2>User Name : {<p>user name</p>}</h2>
		<h2> : {<p>user name</p>}</h2>
		<h2>User Name : {<p>user name</p>}</h2>
		<h2>User Name : {<p>user name</p>}</h2>


		
	  
	</div>
  )
}
